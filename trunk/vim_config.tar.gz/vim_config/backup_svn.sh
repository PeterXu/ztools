#!/bin/bash

PATH=`pwd`
DNAME=`/usr/bin/basename ${PATH}`
TS=`/bin/date +%Y-%m%d-%H%M%S`

BAKNAME=/tmp/${DNAME}_${TS}.diff

/usr/local/bin/svn diff > $BAKNAME
if [ -f $BAKNAME ]; then
	/bin/cp -f $BAKNAME /home/yongze/Desktop/yzxu_m/
	echo "svn diff into '$BAKNAME'"
fi

exit 0
